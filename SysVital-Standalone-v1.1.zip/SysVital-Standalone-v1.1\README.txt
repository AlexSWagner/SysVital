SysVital v1.1 
 
This is a standalone version of SysVital. 
 
Instructions: 
1. Run SysVital.exe 
2. For full functionality, right-click and select "Run as administrator" 
 
For more information, visit: https://github.com/AlexSWagner/SysVital 
